//
//  ViewController.swift
//  12
//
//  Created by User02 on 2018/11/14.
//  Copyright © 2018 User02. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    
    @IBOutlet weak var pic: UIImageView!
    
    @IBOutlet weak var priceTextField: UITextField!
    
    @IBOutlet weak var percentTextField: UITextField!
    
    @IBOutlet weak var costLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func cal(_ sender: Any) {
        view.endEditing(true)
        if let priceText=priceTextField.text,let percentText=percentTextField.text,let price=Double(priceText),let percent=Double(percentText){
            if price > 100{
                let cost=price*percent/100
                costLabel.text="$\(cost)"
                pic.image=UIImage(named: "8TA7AG7Ta2.jpeg")
            }
            else{
                costLabel.text="免成交手續費"
                pic.image=UIImage(named: "pig.jpg")
            }
        }
    }
    
    @IBAction func clear(_ sender: Any) {
        priceTextField.text=""
        percentTextField.text=""
    }
}

